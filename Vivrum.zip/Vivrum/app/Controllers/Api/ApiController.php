<?php

namespace App\Controllers\Api;

use CodeIgniter\RESTful\ResourceController;
use App\Models\UserModel;


class ApiController extends ResourceController
{
	public function addEmployee()
	{
		$rules = [
            
			"first_name" => "required|min_length[3]",
            "last_name" => "required",
			"email" => "required|valid_email|is_unique[user_table.email]|min_length[6]",
			"password" => "required|min_length[6]|max_length[20]|regex_match[[A-Z][a-z]]",
            "profile_pic" => "required",
            "user_type" => "required",
            "mobile_number" => "required|numeric|regex_match[/^[0-9]{10}$/]",
            "child_name" => "required|min_length[3]",	
		];

		$messages = [
			"first_name" => [
				"required" => "first_name is required"
			],
            "last_name" => [
				"required" => "last_name is required"
			],
			"email" => [
				"required" => "Email required",
				"valid_email" => "Email address is not in format",
				"is_unique" => "Email address already exists"
			],
			"password" => [
				"required" => "password is required"
			],
            "profile_pic" => [
                "required" => "profile_pic is required"
            ],
            "user_type" => [
                "required" => "user_type is required"
            ],
            "mobile_number" => [
                "required" => "mobile_number is required"
                
            ],
            "child_name" => [
                "required" => "child_name is required"
            ],
		];

		if (!$this->validate($rules, $messages)) {

			$response = [
				'status' => 500,
				'error' => true,
				'message' => $this->validator->getErrors(),
				'data' => []
			];
		} else {

			$emp = new UserModel();
			$data['first_name'] = $this->request->getVar("first_name");
            $data['last_name'] = $this->request->getVar("last_name");
			$data['email'] = $this->request->getVar("email");
			$data['password'] = base64_encode($this->request->getVar("password"));
            $data['profile_pic'] = $this->request->getVar("profile_pic");
			$data['user_type'] = $this->request->getVar("user_type");
			$data['mobile_number'] = $this->request->getVar("mobile_number");
			$data['child_name'] = $this->request->getVar("child_name");
			$emp->save($data);

			$response = [
				'status' => 200,
				'error' => false,
				'message' => 'Employee added successfully',
				'data' => []
			];
		}

		return $this->respondCreated($response);
	}

	public function listEmployee()
	{
		$emp = new UserModel();

		$response = [
			'status' => 200,
			"error" => false,
			'messages' => 'Employee list',
			'data' => $emp->findAll()
		];

		return $this->respondCreated($response);
	}

	public function singleEmployee($emp_id)
	{
		$emp = new UserModel();

		$data = $emp->find($emp_id);

		if (!empty($data)) {

			$response = [
				'status' => 200,
				"error" => false,
				'messages' => 'Single employee data',
				'data' => $data
			];

		} else {

			$response = [
				'status' => 500,
				"error" => true,
				'messages' => 'No employee found',
				'data' => []
			];
		}

		return $this->respondCreated($response);
	}
//user update creaat

public function updateEmployee($emp_id)
	{
		$rules = [
			"first_name" => "required",
            "last_name" => "required",
            "email" => "required|valid_email|is_unique[user_table.email]|min_length[6]",
            "password" => "required|min_length[6]|max_length[20]|alpha_numeric",
            "profile_pic" => "required",
            "user_type" => "required",
            "mobile_number" => "required|numeric|regex_match[/^[0-9]{10}$/]",
            "child_name" => "required|min_length[3]",
		];

		$messages = [
			"first_name" => [
				"required" => "first_name is required"
			],
            "last_name" => [
				"required" => "last_name is required"
			],
			"email" => [
				"required" => "Email required",
				"valid_email" => "Email address is not in format"
			],
			"password" => [
				"required" => "last_name is required"
			],
            "profile_pic" => [
                "required" => "profile_pic is required"
            ],
            "user_type" => [
                "required" => "user_type is required"
            ],
            "mobile_number" => [
                "required" => "mobile_number is required"
                
            ],
            "child_name" => [
                "required" => "child_name is required"
            ],
		];

		if (!$this->validate($rules, $messages)) {

			$response = [
				'status' => 500,
				'error' => true,
				'message' => $this->validator->getErrors(),
				'data' => []
			];
		} else {

			$emp = new UserModel();

			if ($emp->find($emp_id)) {
				$data['first_name'] = $this->request->getVar("first_name");
                $data['last_name'] = $this->request->getVar("last_name");
				$data['email'] = $this->request->getVar("email");
				$data['password'] = $this->request->getVar("password");
                $data['profile_pic'] = $this->request->getVar("profile_pic");
                $data['user_type'] = $this->request->getVar("user_type");
                $data['mobile_number'] = $this->request->getVar("mobile_number");
                $data['child_name'] = $this->request->getVar("child_name");
				$emp->update($emp_id, $data);
				$response = [
					'status' => 200,
					'error' => false,
					'message' => 'Employee updated successfully',
					'data' => []
				];
			}else {

				$response = [
					'status' => 500,
					"error" => true,
					'messages' => 'No employee found',
					'data' => []
				];
			}
		}

		return $this->respondCreated($response);
	}



// user update close

// user  delete
	public function deleteEmployee($emp_id)
	{
		$emp = new UserModel();

		$data = $emp->find($emp_id);

		if (!empty($data)) {

			$emp->delete($emp_id);

			$response = [
				'status' => 200,
				"error" => false,
				'messages' => 'Employee deleted successfully',
				'data' => []
			];

		} else {

			$response = [
				'status' => 500,
				"error" => true,
				'messages' => 'No employee found',
				'data' => []
			];
		}

		return $this->respondCreated($response);
	}

    // user  delete close

   // user login creat
    public function login()
	{
		$emp = new UserModel();
		$result=$emp->where('email',$this->request->getvar('email'))->first();
	
		if($result != null)
		{
			if($result['password'] == base64_encode( $this->request->getvar('password')))
			{
                $response = [
                    'status' => 200,
                    "error" => false,
                    'messages' => 'user login successfully',
                    'data' => []
                ];
                return $this->respondCreated($response);
			}
            
			else{  
				
                $response = [
                    'status' => 500,
                    "error" => true,
                    'messages' => 'login faild',
                    'data' => []
                ];
				return $this->respondCreated($response);
			}

		}
		
	}
    // user login close
}